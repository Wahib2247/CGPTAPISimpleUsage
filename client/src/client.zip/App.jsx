import ChatWindow from "./components/ChatWindow";
import InputBar from "./components/InputBar";
import { useChat } from "./hooks/useChat";

// App is the root component — it wires everything together
// useChat hook provides all the state and logic
// ChatWindow displays messages
// InputBar handles user input

const App = () => {
  // TODO #18 — Destructure what you need from useChat()
  // You need: messages, isLoading, error, sendMessage, clearChat
  const { messages, isLoading, error, sendMessage, clearChat } = useChat();

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        backgroundColor: "#0f0f1a",
        fontFamily: "sans-serif",
        maxWidth: "800px",
        margin: "0 auto",
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: "16px 20px",
          borderBottom: "1px solid #2a2a3e",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <h1 style={{ color: "#fff", fontSize: "18px", margin: 0 }}>
          AI Chat
        </h1>
        <button
          onClick={clearChat}
          style={{
            padding: "6px 14px",
            borderRadius: "8px",
            border: "1px solid #2a2a3e",
            backgroundColor: "transparent",
            color: "#888",
            cursor: "pointer",
            fontSize: "13px",
          }}
        >
          Clear
        </button>
      </div>

      {/* TODO #19 — Render ChatWindow and InputBar with the correct props */}
      {/* ChatWindow needs: messages, isLoading, error */}
      {/* InputBar needs: onSend (pass the sendMessage function), isLoading */}
      <ChatWindow
        messages={messages}
        isLoading={isLoading}
        error={error}
      />
      <InputBar
        onSend={sendMessage}
        isLoading={isLoading}
      />
    </div>
  );
};

export default App;
