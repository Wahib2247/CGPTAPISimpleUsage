import { useEffect, useRef } from "react";
import MessageBubble from "./MessageBubble";

// ChatWindow displays the scrollable list of messages
// It should automatically scroll to the bottom when new messages arrive

const ChatWindow = ({ messages, isLoading, error }) => {
  const bottomRef = useRef(null);

  // TODO #16 — Auto scroll to bottom when messages change
  // Use a useEffect that watches the `messages` array
  // Inside it, call bottomRef.current?.scrollIntoView({ behavior: "smooth" })
  // This scrolls to the invisible div at the bottom of the list
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  return (
    <div
      style={{
        flex: 1,
        overflowY: "auto",
        padding: "16px",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {messages.length === 0 && (
        <div
          style={{
            textAlign: "center",
            color: "#555",
            marginTop: "40px",
            fontSize: "14px",
          }}
        >
          Start a conversation...
        </div>
      )}

      {/* TODO #17 — Render the messages list */}
      {/* Map over the messages array and render a MessageBubble for each one */}
      {/* Each MessageBubble receives: message={msg} */}
      {/* Use the array index as the key for now: key={index} */}
      {messages.map((msg, index) => (
        <MessageBubble key={index} message={msg} />
      ))}
      {isLoading && (
        <div style={{ textAlign: "left", color: "#888", fontSize: "13px", padding: "8px" }}>
          AI is thinking...
        </div>
      )}

      {error && (
        <div style={{ color: "#f87171", fontSize: "13px", padding: "8px" }}>
          Error: {error}
        </div>
      )}

      {/* This empty div is the scroll target */}
      <div ref={bottomRef} />
    </div>
  );
};

export default ChatWindow;
