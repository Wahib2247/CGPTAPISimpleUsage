// MessageBubble renders a single chat message
// It looks different depending on whether the role is "user" or "assistant"

const MessageBubble = ({ message }) => {
  const isUser = message.role === "user";

  return (
    <div
      style={{
        display: "flex",
        justifyContent: isUser ? "flex-end" : "flex-start",
        marginBottom: "12px",
      }}
    >
      <div
        style={{
          maxWidth: "70%",
          padding: "12px 16px",
          borderRadius: isUser ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
          backgroundColor: isUser ? "#2563eb" : "#1e1e2e",
          color: "#fff",
          fontSize: "14px",
          lineHeight: "1.5",
        }}
      >
        {/* TODO #13 — Render the message content here */}
        {/* Hint: access message.content */}
        {isUser ? "You: " : "AI: "}
        <br />
        {message.content}
      </div>
    </div>
  );
};

export default MessageBubble;
